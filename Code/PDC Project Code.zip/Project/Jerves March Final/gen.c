#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    srand(time(0)); // Initialize random seed with current time

    int numCoordinates = 15; // Number of coordinates to generate

    FILE *file = fopen("file.txt", "w"); // Open file for writing
    if (file == NULL) {
        printf("Error opening file\n");
        return 1;
    }

    for (int i = 0; i < numCoordinates; i++) {
        int x = rand() % 100; // Random x coordinate between 0 and 99
        int y = rand() % 100; // Random y coordinate between 0 and 99

        fprintf(file, "%d %d\n", x, y); // Write coordinates to file
    }

    fclose(file); // Close the file

    printf("Coordinates saved to file.txt\n");

    return 0;
}
//Code to generate random graph
