// JarvisMarch.cpp
#include <iostream>
#include <vector>
#include <algorithm>
#include <ctime>
#include <iomanip>
#include <omp.h>

using namespace std;

struct Point {
    int x, y;
};

int orientation(Point p, Point q, Point r) {
    int val = (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y);
    if (val == 0) return 0;
    return (val > 0) ? 1 : -1;
}

vector<Point> jarvisMarch(vector<Point>& points) {
    int n = points.size();
    if (n < 3) {
        cout << "Convex hull not possible with less than 3 points." << endl;
        return vector<Point>();
    }

    vector<Point> hull;
    int l = 0;
    int p = l, q;

    #pragma omp parallel private(q)
    {
        #pragma omp for
        for (int i = 0; i < n; i++) {
            if (points[i].x < points[l].x)
                l = i;
        }

        #pragma omp barrier // Ensure that all threads have finished finding the initial point

        do {
            #pragma omp critical
            {
                hull.push_back(points[p]);
            }

            q = (p + 1) % n;

            #pragma omp for
            for (int i = 0; i < n; i++) {
                if (orientation(points[p], points[i], points[q]) == -1) {
                    q = i;
                }
            }

            #pragma omp barrier // Ensure that all threads have finished updating q

            #pragma omp single
            {
                p = q;
            }
        } while (p != l);
    }

    return hull;
}

int main() {
    // Example usage with random points
    vector<Point> points = {{0, 3}, {1, 1}, {2, 2}, {4, 4}, {0, 0}, {1, 2}, {3, 1}, {3, 3}};
    
    int num_threads=2;
    omp_set_num_threads(num_threads);

    // Jarvis March
    clock_t start_time = clock();
    vector<Point> jarvisHull = jarvisMarch(points);
    clock_t end_time = clock();
    double jarvisDuration = double(end_time - start_time) / CLOCKS_PER_SEC;

    // Print convex hull and execution time
    cout << "Jarvis March Convex Hull:" << endl;
    for (const Point& p : jarvisHull) {
        cout << "(" << p.x << ", " << p.y << ") ";
    }
    cout << fixed << setprecision(6) << "\nExecution Time: " << jarvisDuration << " seconds" << endl;

    return 0;
}
