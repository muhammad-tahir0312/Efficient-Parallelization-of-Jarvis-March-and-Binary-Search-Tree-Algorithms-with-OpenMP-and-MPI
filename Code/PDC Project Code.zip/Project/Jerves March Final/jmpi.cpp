#include <iostream>
#include <vector>
#include <ctime>
#include <iomanip>
#include <fstream>
#include "mpi.h"

using namespace std;

clock_t start_comm_time;
clock_t end_comm_time;

struct Point {
    int x, y;
};

int orientation(Point p, Point q, Point r) {
    int val = (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y);
    if (val == 0) return 0;
    return (val > 0) ? 1 : -1;
}

void parallelQuicksort(vector<Point>& points, int low, int high);
int parallelPartition(vector<Point>& points, int low, int high);

vector<Point> jarvisMarch(vector<Point>& points) {
    int n = points.size();
    if (n < 3) {
        cout << "Convex hull not possible with less than 3 points." << endl;
        return vector<Point>();
    }

    vector<Point> hull;
    int l = 0;
    for (int i = 1; i < n; i++) {
        if (points[i].x < points[l].x)
            l = i;
    }

    int p = l, q;
    do {
        hull.push_back(points[p]);
        q = (p + 1) % n;
        for (int i = 0; i < n; i++) {
            if (orientation(points[p], points[i], points[q]) == -1) {
                q = i;
            }
        }
        p = q;
    } while (p != l);

    return hull;
}

void parallelSort(vector<Point>& points) {
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int N = points.size();

    points.resize(N);

    int n = N / size;
    vector<Point> localPoints(n);
    MPI_Scatter(&points[0], n * sizeof(Point), MPI_BYTE, &localPoints[0], n * sizeof(Point), MPI_BYTE, 0, MPI_COMM_WORLD);

    // Parallel sorting using quicksort
    // Implement your parallel sorting algorithm here (e.g., parallel quicksort)
    #pragma omp parallel
    {
        #pragma omp single
        parallelQuicksort(localPoints, 0, n - 1);
    }

    MPI_Gather(&localPoints[0], n * sizeof(Point), MPI_BYTE, &points[0], n * sizeof(Point), MPI_BYTE, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        // Measure execution time
        clock_t start_time = clock();

        // Perform Jarvis March on the sorted points
        vector<Point> jarvisHull = jarvisMarch(points);

        // Measure execution time
        clock_t end_time = clock();
        double jarvisDuration = double(end_time - start_time) / CLOCKS_PER_SEC;

        
        // Print convex hull and execution time
        cout << "Jarvis March Convex Hull:" << endl;
        for (const Point& p : jarvisHull) {
            cout << "(" << p.x << ", " << p.y << ") ";
        }
        
        cout << fixed << setprecision(6) << "Computation Time: " << jarvisDuration << " seconds" << endl;
    }
}

// Parallel Quicksort Implementation
void parallelQuicksort(vector<Point>& points, int low, int high) {
    if (low < high) {
        int pi = parallelPartition(points, low, high);

        #pragma omp task shared(points)
        parallelQuicksort(points, low, pi - 1);

        #pragma omp task shared(points)
        parallelQuicksort(points, pi + 1, high);
    }
}

int parallelPartition(vector<Point>& points, int low, int high) {
    Point pivot = points[high];
    int i = low - 1;

    for (int j = low; j < high; j++) {
        if (points[j].x <= pivot.x) {
            i++;
            swap(points[i], points[j]);
        }
    }

    swap(points[i + 1], points[high]);
    return i + 1;
}

int main(int argc, char* argv[]) {
    MPI_Init(&argc, &argv);
    
    // Start communication time
    start_comm_time = clock();

    // Read input from file.txt
    vector<Point> points;
    ifstream inputFile("file.txt");
    if (!inputFile.is_open()) {
        cerr << "Error opening file.txt" << endl;
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    int x, y;
    while (inputFile >> x >> y) {
        Point point = {x, y};
        points.push_back(point);
    }
    inputFile.close();

    // Parallel Sort and Jarvis March
    parallelSort(points);
    
    // End communication time
    end_comm_time = clock();
    
       double commDuration = double(end_comm_time - start_comm_time) / CLOCKS_PER_SEC;

       cout << fixed << setprecision(6) << "\ncommunication Time: " << abs(commDuration) << " seconds" << endl;

    MPI_Finalize();

    return 0;
}

