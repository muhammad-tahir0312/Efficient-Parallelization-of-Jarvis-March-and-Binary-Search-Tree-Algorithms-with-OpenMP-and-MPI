#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <ctime>
#include <iomanip>
#include <chrono>
#include <thread>

using namespace std;

struct Point {
    int x, y;
};

int orientation(Point p, Point q, Point r) {
    int val = (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y);
    if (val == 0) return 0;
    return (val > 0) ? 1 : -1;
}

vector<Point> jarvisMarch(vector<Point>& points) {
    int n = points.size();
    if (n < 3) {
        cout << "Convex hull not possible with less than 3 points." << endl;
        return vector<Point>();
    }

    vector<Point> hull;
    int l = 0;
    for (int i = 1; i < n; i++) {
        if (points[i].x < points[l].x)
            l = i;
    }

    int p = l, q;
    do {
        hull.push_back(points[p]);
        q = (p + 1) % n;
        for (int i = 0; i < n; i++) {
            if (orientation(points[p], points[i], points[q]) == -1) {
                q = i;
            }
        }
        p = q;
    } while (p != l); 

    return hull;
}

int main() {
    // Read input from file.txt
    vector<Point> points;
    ifstream inputFile("file.txt");
    if (!inputFile.is_open()) {
        cerr << "Error opening file.txt" << endl;
        return 1;
    }

    int x, y;
    while (inputFile >> x >> y) {
        Point point = {x, y};
        points.push_back(point);
    }
    inputFile.close();

    // Jarvis March
    clock_t start_time = clock();
    vector<Point> jarvisHull = jarvisMarch(points);
    clock_t end_time = clock();
    double jarvisDuration = double(end_time - start_time) / CLOCKS_PER_SEC;

    // Print convex hull and execution time
    cout << "Jarvis March Convex Hull:" << endl;
    for (const Point& p : jarvisHull) {
        cout << "(" << p.x << ", " << p.y << ") ";
    }
    cout << fixed << setprecision(6) << "\nExecution Time: " << jarvisDuration << " seconds" << endl;

    return 0;
}

