#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct node {
    int key;
    struct node *left, *right;
};

struct node* newNode(int item)
{
    struct node* temp = (struct node*)malloc(sizeof(struct node));
    temp->key = item;
    temp->left = temp->right = NULL;
    return temp;
}

struct node* insert(struct node* node, int key)
{
    if (node == NULL)
        return newNode(key);

    if (key < node->key)
        node->left = insert(node->left, key);
    else if (key > node->key)
        node->right = insert(node->right, key);

    return node;
}

struct node* search(struct node* root, int key)
{
    if (root == NULL || root->key == key)
        return root;

    if (root->key < key)
        return search(root->right, key);

    return search(root->left, key);
}

// Function to measure the execution time
double measureExecutionTime(struct node* root, int key)
{
    clock_t start, end;
    start = clock();

    // Searching in a BST
    if (search(root, key) == NULL)
        printf("%d not found\n", key);
    else
        printf("%d found\n", key);

    end = clock();
    return ((double)(end - start)) / CLOCKS_PER_SEC;
}

int main()
{
    struct node* root = NULL;
    
    // Read input from file.txt
    FILE* inputFile = fopen("file.txt", "r");
    if (inputFile == NULL) {
        perror("Error opening file.txt");
        return 1;
    }

    int x;
    while (fscanf(inputFile, "%d", &x) == 1) {
        root = insert(root, x);
    }
    fclose(inputFile);

    int key = 99;
    
    double executionTime = measureExecutionTime(root, key);
    printf("Execution time for key %d: %lf seconds\n", key, executionTime);

    return 0;
}

